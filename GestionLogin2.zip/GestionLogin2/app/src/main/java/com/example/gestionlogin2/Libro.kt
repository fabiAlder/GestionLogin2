package com.example.gestionlogin2

data class Libro (
    val titulo:String,
    val autor:String
)

