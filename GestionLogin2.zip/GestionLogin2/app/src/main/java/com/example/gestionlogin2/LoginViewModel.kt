package com.example.gestionlogin2

import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel() {


    val username: MutableState<String> = mutableStateOf("")
    val password: MutableState<String> = mutableStateOf("")
    val correo: MutableState<String> = mutableStateOf("")
    private val _isLoggedIn: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()
    val errorMessage: MutableState<String> = mutableStateOf("")

    private val users = listOf(
        "fabian@iesteis.gal" to "123456",
        "Alderete@iesteis.gal" to "1234567"

    )

    private var loginAttempts: Int = 3

    fun onUsernameChange(value: String) {
        username.value = value
    }

    fun onPasswordChange(value: String) {
        password.value = value
    }

    fun login() {
        val user = users.find { it.first == username.value && it.second == password.value }
        if (user != null) {
            _isLoggedIn.value = true
            errorMessage.value = ""
            Log.d("LoginViewModel", "Usuario autenticado, isLoggedIn = true")
        } else {
            loginAttempts--
            _isLoggedIn.value = false
            errorMessage.value = if (loginAttempts > 0) {
                "Usuario no encontrado o contraseña incorrecta. Intentos restantes: $loginAttempts"
            } else {
                "Has agotado todos los intentos. Por favor, intenta más tarde."
            }
            Log.d("LoginViewModel", "Usuario no encontrado o contraseña incorrecta. Intentos restantes: $loginAttempts")
        }
    }
    var state by mutableStateOf(LibroState())
        private set


    init {
        viewModelScope.launch {
            state = state.copy(//Ultimo.2
                estaCargando = true
            )
            delay(5000)


            state=state.copy(
                libreria= listOf(
                    Libro("Clean Code","Robert C Martin"),
                    Libro("Refactoring","Martin Fowler"),
                    Libro("Effective Java","Joshua Bloch")
                ),
                estaCargando = false
            )
        }
    }

    fun libroCliked(libro:Libro){
//
        val index = state.libreria.indexOf(libro)

        val libreriaModificada = state.libreria.toMutableList()
        libreriaModificada.removeAt(index)

        state=state.copy(
            libreria=libreriaModificada
        )
    }
}




