package com.example.gestionlogin2

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.gestionlogin2.ui.theme.GestionLogin2Theme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GestionLogin2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                   // val viewModel1: LibroViewModel by viewModels()
                    val viewModel: LoginViewModel by viewModels()
                    val isLoggedIn by viewModel.isLoggedIn.collectAsState()

                    if (isLoggedIn) {
                        LoginValidado()
                    } else {
                        LoginScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }




}

@Composable
fun LoginScreen(viewModel: LoginViewModel) {
    val usernameState = viewModel.username
    val passwordState = viewModel.password
    val errorMessageState = viewModel.errorMessage

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = usernameState.value,
            onValueChange = { viewModel.onUsernameChange(it) },
            label = { Text("Usuario") },
            modifier = Modifier.padding(bottom = 16.dp)
        )

        OutlinedTextField(
            value = passwordState.value,
            onValueChange = { viewModel.onPasswordChange(it) },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Button(
            onClick = { viewModel.login() }
        ) {
            Text(text = "Enviar")
        }

        if (errorMessageState.value.isNotEmpty()) {
            Text(
                text = errorMessageState.value,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginValidado(
   //logginError: Boolean,
    onLogin: (String, String, String) -> Unit,
) {
    var nombre by rememberSaveable { mutableStateOf("") }
    var emailString by rememberSaveable { mutableStateOf("") }
    var passwordString by rememberSaveable { mutableStateOf("") }

    //if (logginError)
        //Text(
            //text = "Email o contraseña inválidos"
        //)

    OutlinedTextField(
        value = nombre, onValueChange = { nombre = it.trim() },
        label = { Text(text = "nombre de usuario") },
        //isError = logginError
    )
    OutlinedTextField(
        value = emailString, onValueChange = { emailString = it.trim() },
        label = { Text(text = "Email") },
       // isError = logginError
    )
    OutlinedTextField(
        value = passwordString, onValueChange = { passwordString = it },
        label = { Text(text = "Contraseña") },
        //isError = logginError,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
    )
    Button(
        onClick = { onLogin(emailString, passwordString, nombre) },
        enabled = emailString.isValidEmail() && passwordString.isValidPassword() &&
                nombre.isValidNombre()
    ) {
        Text(text = "Alta")
    }

}

private const val MIN_SIZE_NAME = 3
private const val MIN_SIZE_PASSWORD = 3
fun String.isValidNombre() = this.length > MIN_SIZE_NAME
fun String.isValidPassword() = this.length > MIN_SIZE_PASSWORD
fun String.isValidEmail() = Patterns.EMAIL_ADDRESS.matcher(this).matches()

@Composable
fun LoginScreenLogueado(viewModel: LoginViewModel) {
    //val usernameState = viewModel.username
    //val passwordState = viewModel.password
    val errorMessageState = viewModel.errorMessage

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = "",
            onValueChange = { viewModel.onUsernameChange(it) },
            label = { Text("nombre de usuario") },
            modifier = Modifier.padding(bottom = 16.dp)
        )

        OutlinedTextField(
            value = "",
            onValueChange = { viewModel.onPasswordChange(it) },
            label = { Text("mail") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.padding(bottom = 16.dp)
        )
        OutlinedTextField(
            value = "",
            onValueChange = { viewModel.onUsernameChange(it) },
            label = { Text("contraseña") },
            modifier = Modifier.padding(bottom = 16.dp)
        )
        OutlinedTextField(
            value = "",
            onValueChange = { viewModel.onUsernameChange(it) },
            label = { Text("repetir contraseña") },
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Button(
            onClick = { viewModel.login() }
        ) {
            Text(text = "Alta")
        }

        if (errorMessageState.value.isNotEmpty()) {
            Text(
                text = errorMessageState.value,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
}


@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable

fun MainScreenLibro(LibroViewModel: LoginViewModel){

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                title = { Text(text = "Listado Libros") })
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
                Text(text = "Num.Libros->${LibroViewModel.state.libreria.size}")
//                Text(text = "Screen4")
            }
        }
    ) {
        //ultimo.3-
        val state = LibroViewModel.state
        //ultimo.5-
        if (state.estaCargando) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }

        Column(
            Modifier.padding(it)//solución2- directamente meter los padding() en el Column
                .fillMaxSize()
                .padding(35.dp),
//            horizontalAlignment = Alignment.CenterHorizontally,
//            verticalArrangement = Arrangement.SpaceEvenly
        ) {

            //    val libreria = listOf<Libro>()
//pero no queremos hacer aqui directamente la creación, realmente se sacará de BD, API-servicio..
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                //items(LibroViewModel.libreria){//cada uno de los items->libros
                //ultimo.4-
                items(state.libreria) {
                    Column(modifier = Modifier.fillMaxWidth().clickable{
                        LibroViewModel.libroCliked(it)
                    }) {
                        Text(text = it.titulo)
                        Text(text = it.autor)
                        Divider()
                    }
                }
            }
        }
    }
}


